# Wardriving Analyzer v4.2

Multi-spectrum RF site survey analysis tool with ML-based AP classification.

## What's New in v4.2

### Bug Fixes
- **Fixed multi-select "View Selected"** - Multiple selected SOIs now display correctly in Map View
- **Fixed report generation** - Reports now only include selected SOIs (or all visible if none selected)
- **Fixed run removal** - Clearing unchecked runs now properly removes them from the display and data

### UI Improvements
- **Selection mode indicator** - Map shows "Showing X selected SOI(s)" with "Show All" button
- **Map deselects on click** - Clicking empty map area clears selection and exits selection mode

### v4.1 Features
- Table selection checkboxes work correctly
- Security column in table view (N/A for BLE)
- Matter/Zigbee device filter
- Security filter auto-switches to WiFi
- Filtered/Selected statistics section
- Report format selector (PDF/HTML) in Settings
- GPS-only classification scoring

## Quick Start

```bash
tar -xzf wardriving_analyzer.tar.gz
cd wardriving_analyzer
./install.sh
./run.sh
```

Open http://localhost:5000

## Usage

### Loading Data
- Click upload zone, select one or more CSV files
- Multiple files load as separate "runs"
- Uncheck runs and click "Clear Selected" to remove them

### Selecting SOIs
1. Switch to Table View
2. Check boxes next to SOIs you want to focus on
3. Click "View Selected" to see only those on the map
4. Click empty map area to show all again

### Generating Reports
1. Select SOIs in table (optional - if none, uses visible filtered)
2. Open Settings, choose PDF or HTML format
3. Click the Report button
4. Report will include only selected/visible SOIs

### Exports
- **Report**: Selected SOIs only (PDF or HTML)
- **GeoJSON/KML/CSV**: All loaded data

## Classification Algorithm

1. **RSSI Variance** (30%): High variance = likely mobile
2. **Geographic Spread** (30%): Large spread = likely mobile
3. **DBSCAN Clustering** (30%): Multiple clusters = likely mobile
4. **Run Consistency** (10%): Seen in multiple runs = likely static

Only GPS-valid detections are used for scoring.

## Requirements

- Python 3.10+
- Flask, pandas, numpy, scikit-learn, reportlab

## License

MIT License
