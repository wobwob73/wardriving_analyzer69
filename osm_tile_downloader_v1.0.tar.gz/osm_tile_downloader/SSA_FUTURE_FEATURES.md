# Silver Streak Analyzer (SSA) - Future Implementation List

This document tracks planned features and enhancements for SSA.

---

## Settings Tab Enhancements

### Map Tiles Tab (NEW)

**Priority:** Medium  
**Added:** 2026-01-19  
**Status:** Planned

A new tab under Settings for managing offline map tiles.

#### Features:
1. **Import Map Tile File**
   - Button to import `.mbtiles` files
   - File browser dialog
   - Validates MBTiles format before import
   - Shows import progress for large files
   - Copies file to SSA tiles directory

2. **Tile Library Management**
   - List of all imported tile files
   - Shows: filename, size, source, coverage area, zoom levels
   - Delete button for each file
   - Preview thumbnail of coverage area

3. **Tile Source Priority**
   - Drag-and-drop ordering of tile sources
   - Options: Imported files first, Online first, Offline only
   - Fallback behavior configuration

4. **Coverage Visualization**
   - Mini-map showing coverage areas of all tile files
   - Different colors for different zoom level coverage
   - Helps identify gaps in coverage

#### UI Mockup:
```
┌─────────────────────────────────────────────────────────┐
│ Settings > Map Tiles                                    │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  [Import Map Tile File]                                 │
│                                                         │
│  ┌─────────────────────────────────────────────────────┐│
│  │ Imported Tile Files                                 ││
│  ├─────────────────────────────────────────────────────┤│
│  │ □ region_dark.mbtiles     │ 156 MB │ z10-16 │ [×]  ││
│  │ □ downtown_detail.mbtiles │  45 MB │ z14-18 │ [×]  ││
│  │ □ highway_corridor.mbtiles│  78 MB │ z12-16 │ [×]  ││
│  └─────────────────────────────────────────────────────┘│
│                                                         │
│  Tile Source Priority:                                  │
│  ○ Offline first (use imported, fallback to online)    │
│  ○ Online first (use online, fallback to imported)     │
│  ● Offline only (never use online tiles)               │
│                                                         │
│  Active Online Source (when online enabled):           │
│  [CartoDB Dark Matter          ▼]                      │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

#### Implementation Notes:
- MBTiles files stored in `~/.ssa/tiles/` directory
- Leaflet TileLayer.MBTiles plugin or custom loader needed
- Need to handle TMS vs XYZ y-coordinate flipping
- Consider lazy-loading tile metadata for large libraries

#### Related:
- OSM Tile Downloader standalone tool (completed)
- See `/osm_tile_downloader/` for tile preparation utility

---

## Previously Identified Enhancements

(From earlier planning sessions)

### Report Generation
- [ ] Timestamps in list view (fixed Zulu time)
- [ ] Advanced sorting options dropdown
- [ ] Dark mode color palettes (sunset, blues, greens, industrial yellows, sepia)
- [ ] Name commonality analysis (manufacturer/provider/custom pie charts)
- [ ] Summary vs Full report dropdown
- [ ] Wigle CSV export option
- [ ] MAC address list-of-interest CSV export
- [ ] Run comparison/diff report with Focus Mode highlighting

### Filter Options
- [ ] Duplicate SSID detection checkbox (same SSID, different MACs)
- [ ] Channel utilization visualization improvement

### UI Enhancements  
- [ ] Collapsible tagging menu for SOIs (like playback controls)
- [ ] Map view search/filter bar
- [ ] Keyboard shortcuts
- [ ] Session auto-save

### Data Management
- [ ] Session save/load functionality
- [ ] OUI/Vendor lookup from MAC address

---

## Version History

| Version | Date | Major Features |
|---------|------|----------------|
| 4.6.0-alpha | Current | Multi-select fixes, GNSS Link integration |
| 4.5.x | Previous | Report generation, dark mode maps |
| 4.4.x | Previous | Basemap options, version tab |

---

*Last updated: 2026-01-19*
