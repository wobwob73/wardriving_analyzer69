#!/usr/bin/env python3
"""
OSM Tile Downloader for Silver Streak Analyzer (SSA)
Downloads map tiles for offline use in MBTiles format.

Usage:
    python tile_downloader.py --center LAT,LON --radius DISTANCE --zoom MIN-MAX --output FILE
    python tile_downloader.py --bbox SOUTH,WEST,NORTH,EAST --zoom MIN-MAX --output FILE

Examples:
    python tile_downloader.py --center 35.12,-79.45 --radius 10km --zoom 10-16 --output my_area.mbtiles
    python tile_downloader.py --bbox 35.0,-79.5,35.3,-79.0 --zoom 10-17 --output region.mbtiles
"""

import argparse
import math
import os
import sqlite3
import sys
import time
import json
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError
from concurrent.futures import ThreadPoolExecutor, as_completed

# Tile source configurations
TILE_SOURCES = {
    'osm': {
        'name': 'OpenStreetMap',
        'url': 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
        'attribution': '© OpenStreetMap contributors',
        'max_zoom': 19
    },
    'cartodb-dark': {
        'name': 'CartoDB Dark Matter',
        'url': 'https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png',
        'attribution': '© CartoDB © OpenStreetMap contributors',
        'max_zoom': 20
    },
    'cartodb-light': {
        'name': 'CartoDB Positron',
        'url': 'https://a.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png',
        'attribution': '© CartoDB © OpenStreetMap contributors',
        'max_zoom': 20
    },
    'opentopomap': {
        'name': 'OpenTopoMap',
        'url': 'https://tile.opentopomap.org/{z}/{x}/{y}.png',
        'attribution': '© OpenTopoMap contributors',
        'max_zoom': 17
    },
    'stamen-terrain': {
        'name': 'Stamen Terrain',
        'url': 'https://tiles.stadiamaps.com/tiles/stamen_terrain/{z}/{x}/{y}.png',
        'attribution': '© Stamen Design © OpenStreetMap contributors',
        'max_zoom': 18
    }
}

# User agent for requests (be a good citizen)
USER_AGENT = 'SSA-TileDownloader/1.0 (Offline map caching for personal use)'


def lat_lon_to_tile(lat, lon, zoom):
    """Convert latitude/longitude to tile coordinates at given zoom level."""
    lat_rad = math.radians(lat)
    n = 2 ** zoom
    x = int((lon + 180.0) / 360.0 * n)
    y = int((1.0 - math.asinh(math.tan(lat_rad)) / math.pi) / 2.0 * n)
    return x, y


def tile_to_lat_lon(x, y, zoom):
    """Convert tile coordinates to latitude/longitude (NW corner of tile)."""
    n = 2 ** zoom
    lon = x / n * 360.0 - 180.0
    lat_rad = math.atan(math.sinh(math.pi * (1 - 2 * y / n)))
    lat = math.degrees(lat_rad)
    return lat, lon


def parse_distance(distance_str):
    """Parse distance string like '10km' or '5mi' to meters."""
    distance_str = distance_str.lower().strip()
    if distance_str.endswith('km'):
        return float(distance_str[:-2]) * 1000
    elif distance_str.endswith('mi'):
        return float(distance_str[:-2]) * 1609.34
    elif distance_str.endswith('m'):
        return float(distance_str[:-1])
    else:
        # Assume kilometers if no unit
        return float(distance_str) * 1000


def get_bounding_box_from_center(lat, lon, radius_meters):
    """Calculate bounding box from center point and radius."""
    # Approximate degrees per meter at given latitude
    lat_deg_per_m = 1 / 111320.0
    lon_deg_per_m = 1 / (111320.0 * math.cos(math.radians(lat)))
    
    lat_delta = radius_meters * lat_deg_per_m
    lon_delta = radius_meters * lon_deg_per_m
    
    return {
        'south': lat - lat_delta,
        'north': lat + lat_delta,
        'west': lon - lon_delta,
        'east': lon + lon_delta
    }


def get_tiles_for_bbox(bbox, zoom_min, zoom_max):
    """Get list of all tiles needed for bounding box across zoom levels."""
    tiles = []
    
    for zoom in range(zoom_min, zoom_max + 1):
        # Get tile coordinates for corners
        x_min, y_max = lat_lon_to_tile(bbox['south'], bbox['west'], zoom)
        x_max, y_min = lat_lon_to_tile(bbox['north'], bbox['east'], zoom)
        
        # Ensure proper ordering
        if x_min > x_max:
            x_min, x_max = x_max, x_min
        if y_min > y_max:
            y_min, y_max = y_max, y_min
        
        for x in range(x_min, x_max + 1):
            for y in range(y_min, y_max + 1):
                tiles.append((zoom, x, y))
    
    return tiles


def download_tile(source_config, zoom, x, y, retry_count=3):
    """Download a single tile with retries."""
    url = source_config['url'].format(z=zoom, x=x, y=y)
    
    for attempt in range(retry_count):
        try:
            req = Request(url, headers={'User-Agent': USER_AGENT})
            with urlopen(req, timeout=30) as response:
                return response.read()
        except (URLError, HTTPError) as e:
            if attempt < retry_count - 1:
                time.sleep(1 * (attempt + 1))  # Backoff
            else:
                print(f"  Warning: Failed to download tile z={zoom} x={x} y={y}: {e}")
                return None
    return None


def create_mbtiles_db(output_path, source_config, bbox):
    """Create and initialize MBTiles database."""
    if os.path.exists(output_path):
        os.remove(output_path)
    
    conn = sqlite3.connect(output_path)
    cursor = conn.cursor()
    
    # Create MBTiles schema
    cursor.execute('''
        CREATE TABLE metadata (
            name TEXT,
            value TEXT
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE tiles (
            zoom_level INTEGER,
            tile_column INTEGER,
            tile_row INTEGER,
            tile_data BLOB
        )
    ''')
    
    cursor.execute('''
        CREATE UNIQUE INDEX tile_index ON tiles (zoom_level, tile_column, tile_row)
    ''')
    
    # Insert metadata
    metadata = [
        ('name', f'SSA Offline Tiles - {source_config["name"]}'),
        ('type', 'baselayer'),
        ('version', '1.0'),
        ('description', f'Offline map tiles for Silver Streak Analyzer'),
        ('format', 'png'),
        ('attribution', source_config['attribution']),
        ('bounds', f"{bbox['west']},{bbox['south']},{bbox['east']},{bbox['north']}"),
        ('center', f"{(bbox['west']+bbox['east'])/2},{(bbox['south']+bbox['north'])/2}"),
    ]
    
    cursor.executemany('INSERT INTO metadata VALUES (?, ?)', metadata)
    conn.commit()
    
    return conn


def flip_y(y, zoom):
    """Convert TMS y coordinate to XYZ (or vice versa). MBTiles uses TMS."""
    return (2 ** zoom) - 1 - y


def main():
    parser = argparse.ArgumentParser(
        description='Download map tiles for offline use in Silver Streak Analyzer',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  Download 10km radius around a point (zoom levels 10-16):
    python tile_downloader.py --center 35.12,-79.45 --radius 10km --zoom 10-16 --output area.mbtiles

  Download a specific bounding box:
    python tile_downloader.py --bbox 35.0,-79.5,35.3,-79.0 --zoom 10-17 --output region.mbtiles

  Use CartoDB Dark tiles (matches SSA default):
    python tile_downloader.py --source cartodb-dark --center 35.12,-79.45 --radius 5km --zoom 12-18 --output dark.mbtiles

Available tile sources:
  osm            - OpenStreetMap (standard)
  cartodb-dark   - CartoDB Dark Matter (matches SSA) [DEFAULT]
  cartodb-light  - CartoDB Positron (light theme)
  opentopomap    - OpenTopoMap (topographic)
  stamen-terrain - Stamen Terrain (natural)
        '''
    )
    
    # Area selection (mutually exclusive)
    area_group = parser.add_mutually_exclusive_group(required=True)
    area_group.add_argument('--center', type=str,
                           help='Center point as LAT,LON (e.g., 35.12,-79.45)')
    area_group.add_argument('--bbox', type=str,
                           help='Bounding box as SOUTH,WEST,NORTH,EAST')
    
    parser.add_argument('--radius', type=str, default='10km',
                       help='Radius around center point (e.g., 10km, 5mi). Default: 10km')
    parser.add_argument('--zoom', type=str, default='10-16',
                       help='Zoom level range as MIN-MAX (e.g., 10-16). Default: 10-16')
    parser.add_argument('--source', type=str, default='cartodb-dark',
                       choices=list(TILE_SOURCES.keys()),
                       help='Tile source. Default: cartodb-dark')
    parser.add_argument('--output', '-o', type=str, required=True,
                       help='Output MBTiles file path')
    parser.add_argument('--threads', type=int, default=4,
                       help='Number of download threads. Default: 4')
    parser.add_argument('--delay', type=float, default=0.1,
                       help='Delay between requests in seconds. Default: 0.1')
    
    args = parser.parse_args()
    
    # Parse zoom range
    if '-' in args.zoom:
        zoom_min, zoom_max = map(int, args.zoom.split('-'))
    else:
        zoom_min = zoom_max = int(args.zoom)
    
    source_config = TILE_SOURCES[args.source]
    
    # Clamp zoom to source maximum
    if zoom_max > source_config['max_zoom']:
        print(f"Note: {source_config['name']} max zoom is {source_config['max_zoom']}, clamping.")
        zoom_max = source_config['max_zoom']
    
    # Parse area
    if args.center:
        lat, lon = map(float, args.center.split(','))
        radius = parse_distance(args.radius)
        bbox = get_bounding_box_from_center(lat, lon, radius)
        print(f"Area: {radius/1000:.1f}km radius around ({lat:.4f}, {lon:.4f})")
    else:
        parts = list(map(float, args.bbox.split(',')))
        bbox = {'south': parts[0], 'west': parts[1], 'north': parts[2], 'east': parts[3]}
        print(f"Area: Bounding box ({bbox['south']:.4f}, {bbox['west']:.4f}) to ({bbox['north']:.4f}, {bbox['east']:.4f})")
    
    print(f"Source: {source_config['name']}")
    print(f"Zoom levels: {zoom_min} to {zoom_max}")
    
    # Calculate tiles needed
    tiles = get_tiles_for_bbox(bbox, zoom_min, zoom_max)
    total_tiles = len(tiles)
    
    # Estimate file size (rough: ~15KB per tile average)
    est_size_mb = total_tiles * 15 / 1024
    
    print(f"Total tiles to download: {total_tiles:,}")
    print(f"Estimated file size: ~{est_size_mb:.1f} MB")
    print(f"Estimated time: ~{total_tiles * args.delay / 60:.1f} minutes (with {args.delay}s delay)")
    print()
    
    # Confirm if large download
    if total_tiles > 5000:
        response = input(f"This will download {total_tiles:,} tiles. Continue? [y/N]: ")
        if response.lower() != 'y':
            print("Cancelled.")
            return
    
    # Ensure output directory exists
    output_dir = os.path.dirname(args.output)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # Create database
    print(f"Creating {args.output}...")
    conn = create_mbtiles_db(args.output, source_config, bbox)
    cursor = conn.cursor()
    
    # Download tiles
    downloaded = 0
    failed = 0
    start_time = time.time()
    
    print("Downloading tiles...")
    print()
    
    # Group tiles by zoom for progress display
    tiles_by_zoom = {}
    for z, x, y in tiles:
        if z not in tiles_by_zoom:
            tiles_by_zoom[z] = []
        tiles_by_zoom[z].append((x, y))
    
    for zoom in sorted(tiles_by_zoom.keys()):
        zoom_tiles = tiles_by_zoom[zoom]
        zoom_count = len(zoom_tiles)
        print(f"  Zoom {zoom}: {zoom_count:,} tiles", end='', flush=True)
        
        zoom_downloaded = 0
        zoom_failed = 0
        
        for i, (x, y) in enumerate(zoom_tiles):
            # Download tile
            tile_data = download_tile(source_config, zoom, x, y)
            
            if tile_data:
                # MBTiles uses TMS y-coordinate (flipped)
                tms_y = flip_y(y, zoom)
                cursor.execute(
                    'INSERT OR REPLACE INTO tiles VALUES (?, ?, ?, ?)',
                    (zoom, x, tms_y, tile_data)
                )
                zoom_downloaded += 1
                downloaded += 1
            else:
                zoom_failed += 1
                failed += 1
            
            # Progress indicator
            if (i + 1) % 100 == 0 or i == zoom_count - 1:
                pct = (i + 1) / zoom_count * 100
                print(f"\r  Zoom {zoom}: {i+1:,}/{zoom_count:,} ({pct:.0f}%)", end='', flush=True)
            
            # Rate limiting
            time.sleep(args.delay)
        
        # Commit after each zoom level
        conn.commit()
        
        status = ""
        if zoom_failed > 0:
            status = f" ({zoom_failed} failed)"
        print(f"\r  Zoom {zoom}: {zoom_downloaded:,}/{zoom_count:,} downloaded{status}    ")
    
    conn.close()
    
    # Summary
    elapsed = time.time() - start_time
    file_size = os.path.getsize(args.output) / (1024 * 1024)
    
    print()
    print("=" * 50)
    print("Download Complete!")
    print("=" * 50)
    print(f"  Output file: {args.output}")
    print(f"  File size: {file_size:.1f} MB")
    print(f"  Tiles downloaded: {downloaded:,}")
    if failed > 0:
        print(f"  Tiles failed: {failed:,}")
    print(f"  Time elapsed: {elapsed/60:.1f} minutes")
    print()
    print("To use in SSA:")
    print(f"  1. Copy '{os.path.basename(args.output)}' to your SSA tiles directory")
    print("  2. In SSA, go to Settings > Map Tiles")
    print("  3. Click 'Import Map Tile File' and select the file")
    print()


if __name__ == '__main__':
    main()
